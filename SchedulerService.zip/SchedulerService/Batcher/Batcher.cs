﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batcher
{
    public class Batcher
    {
        public List<List<InputPortfolioQtrend>> BuildBatches( List<InputPortfolioQtrend> accounts)
        {
            List<List<InputPortfolioQtrend>> batches = new List<List<InputPortfolioQtrend>>();
            List<string> batch = new List<string>();
            int batchcount = 0;//should be configurable
            for (int i=0;i<accounts.Count;i++)
            {

                batches[batchcount].Add(accounts[i]);
                if (accounts.Count / (i + 1) == 0)
                {
                    batches.Add(new List<InputPortfolioQtrend>());
                    batchcount++;
                }
            }
            return batches;
        }
    }

    public class InputPortfolioQtrend
    {
        public string Qtrend;
        public string portfolio;
    }
}
