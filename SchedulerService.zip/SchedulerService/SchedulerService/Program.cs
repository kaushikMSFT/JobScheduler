﻿using Batcher;
using DataFlowProcessor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SchedulerService
{
    class Program
    {
        static void Main(string[] args)
        {
            while(true)
            {
                //Give me work..I am hungry


                //From state store
                //Get all items that are pending an action

                //For each item
                //Get workflowtype
                //Find the next step
                //Post a task for the agent for this next step

                //CreateNewPipelines
                List<InputPortfolioQtrend> inputportfolios = new List<InputPortfolioQtrend>();
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12334443", Qtrend = "3/31/2019" });
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12334523", Qtrend = "3/31/2019" });
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12334453", Qtrend = "3/31/2019" });
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12336523", Qtrend = "3/31/2019" });
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12334443", Qtrend = "3/31/2019" });
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12364523", Qtrend = "3/31/2019" });
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12384443", Qtrend = "3/31/2019" });
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12334523", Qtrend = "3/31/2019" });
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12234443", Qtrend = "3/31/2019" });
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12336523", Qtrend = "3/31/2019" });
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12388743", Qtrend = "3/31/2019" });
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12224523", Qtrend = "3/31/2019" });
                BillingInputOutputBaseDTO input = new BillingInputOutputBaseDTO() { portfolioQtrends = inputportfolios };

                Batcher.Batcher batcher = new Batcher.Batcher();
                List<List<InputPortfolioQtrend>> batches=batcher.BuildBatches(inputportfolios);
                batches.ForEach(accountlist => { CreateAndExecuteNewPipeline(new BillingInputOutputBaseDTO() { portfolioQtrends = accountlist }); });

                //Enough..Going to sleep now
                Thread.Sleep(60000);

                //ResumePendingOrFaailedPipelines
                //We dnt need batcher once pipelnes are triggered
                IStep resumingFrom = new CalculateFeeAmountsStep();
                inputportfolios = new List<InputPortfolioQtrend>();
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12334443", Qtrend = "3/31/2019" });
                inputportfolios.Add(new InputPortfolioQtrend() { portfolio = "12334523", Qtrend = "3/31/2019" });
                input = new BillingInputOutputBaseDTO() { portfolioQtrends = inputportfolios };
                resumingFrom.Input = input;
                ResumeFailedPipeline(resumingFrom);

                //Enough..Going to sleep now
                Thread.Sleep(60000);

                
                
                ;
            }
        }

        private static void ResumeFailedPipeline(IStep resumingFrom)
        {
            using (DataFlowPipelineProcessor dp = new DataFlowPipelineProcessor())
            {
                
                dp.ExecuteNewWorkflow(resumingFrom);
            }
        }

        private static void CreateAndExecuteNewPipeline(BillingInputOutputBaseDTO input)
        {
            using (DataFlowPipelineProcessor dp = new DataFlowPipelineProcessor())
            {
                CalculateExtractStep start = new CalculateExtractStep();
              
                start.Input = input;
                dp.ExecuteNewWorkflow(start);
            }
        }
    }

    
}
