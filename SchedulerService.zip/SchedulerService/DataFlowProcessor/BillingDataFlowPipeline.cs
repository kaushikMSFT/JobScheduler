﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace DataFlowProcessor
{

    public class DataFlowPipelineProcessor:IDisposable
    {
        //
        // Connect the dataflow blocks to form a pipeline.
        //

        public void ExecuteNewWorkflow(IStep head)
        {
            CreatePipeline(head);
            Execute();
        }

        public void ResumePendingWorkflows()
        {

        }
        private TransformBlock<BillingInputDTO, BillingOutputFeeRatesDTO> head;
        private TransformBlock<BillingInputOutputBaseDTO, BillingInputOutputBaseDTO> tail;

        private TransformBlock<BillingInputOutputBaseDTO,BillingInputOutputBaseDTO> CreatePipeline(IStep headStep)
        {
            IStep curr = headStep;
            IStep prev = null;
            TransformBlock<BillingInputOutputBaseDTO,BillingInputOutputBaseDTO> prevBlock=null , headBlock=null, currBlock= null;
            while(curr!=null)
            {
                currBlock = new TransformBlock<BillingInputOutputBaseDTO, BillingInputOutputBaseDTO>(curr.Execute);// stepTypesFuncMap[curr.StepType]);
                if (curr == headStep)
                    headBlock = currBlock;
                if(prev!=null)
                {
                    prevBlock.LinkTo(currBlock);
                }
                prevBlock = currBlock;
                prev = curr;
                curr = curr.NextStep;
            }
            #region CommentedCode
            //Create transformBlock for step
            //public static IDictionary<StepTypes,Func<BillingInputOutputBaseDTO, BillingInputOutputBaseDTO>> stepTypesFuncMap = new Dictionary<StepTypes, Func<BillingInputOutputBaseDTO, BillingInputOutputBaseDTO>>();

            // DataflowLinkOptions linkOptions = new DataflowLinkOptions { PropagateCompletion = true };
            // CalculateFeeRatesStep<BillingInputDTO, BillingOutputFeeRatesDTO> step1 = new CalculateFeeRatesStep<BillingInputDTO, BillingOutputFeeRatesDTO>();
            //CalculateFeeAmountsStep<BillingOutputFeeRatesDTO, BillingOutputFeeAmountsDTO> step2 = new CalculateFeeAmountsStep<BillingOutputFeeRatesDTO, BillingOutputFeeAmountsDTO>();

            //step1.dataFlow.LinkTo(step2.dataFlow);
            //head = step1.dataFlow; 
            #endregion          
            tail = currBlock;
            return headBlock;
        }

      
        private void Execute()
        {
            head.Post(new BillingInputDTO()
            {
                portfolioQtrends = new List<InputPortfolioQtrend>()
                                                        {
                                                            new InputPortfolioQtrend() { portfolio = "123", Qtrend = "2/9/2012" },
                                                            new InputPortfolioQtrend() { portfolio = "123", Qtrend = "2/9/2012" }
                                                        }
            });

            head.Complete();
            tail.Completion.Wait();
        }

        public void Dispose()
        {
            
        }
    }

  
}
