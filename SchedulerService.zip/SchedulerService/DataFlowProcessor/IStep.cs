﻿using System.Threading.Tasks.Dataflow;

namespace DataFlowProcessor
{
    public interface IStep
    {
        string JobId { get; }
       
        IStep NextStep { get;  }
        //TransformBlock<T1,T2> dataflow { get; set; }
        StepTypes StepType { get;  }
       BillingInputOutputBaseDTO Input { get; set; }
        BillingInputOutputBaseDTO Output { get; set; }
        BillingInputOutputBaseDTO Execute(BillingInputOutputBaseDTO input);

    }

    public enum StepTypes
    {
        Extract,
        AUM,
        FeeRates,
        FeeAmounts
    }
}