﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace DataFlowProcessor
{
   

    public class CalculateExtractStep : IStep
    {
        public TransformBlock<BillingInputDTO, BillingOutputFeeRatesDTO> dataFlow;

        public string AgentName { get { return "Extract"; } }

        public IStep NextStep { get { return new CalculateFeeRatesStep(); } }

        public StepTypes StepType => throw new NotImplementedException();

        public BillingInputOutputBaseDTO Input { get; set ; }
        public BillingInputOutputBaseDTO Output { get; set; }

        public string JobId { get; set; }

        public BillingInputOutputBaseDTO Execute(BillingInputOutputBaseDTO input)
        {
            return new BillingInputOutputBaseDTO();
        }
    }

    public class CalculateFeeRatesStep : IStep
    {


        public TransformBlock<BillingInputDTO, BillingOutputFeeRatesDTO> dataFlow;


        public BillingOutputFeeRatesDTO Execute(BillingInputDTO input)
        {
            dataFlow = new TransformBlock<BillingInputDTO, BillingOutputFeeRatesDTO>(CalculateFeeRates);
            return new BillingOutputFeeRatesDTO();
        }

        public string AgentName { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public TransformBlock<BillingInputDTO, BillingOutputFeeAmountsDTO> dataflow { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public StepTypes StepType { get { return StepTypes.FeeRates; } }
        public BillingInputOutputBaseDTO Input { get; set; }
        public BillingInputOutputBaseDTO Output { get; set; }
        public IStep NextStep { get { return new CalculateFeeAmountsStep(); } }

        public string JobId { get; set; }

        public BillingOutputFeeRatesDTO CalculateFeeRates(BillingInputDTO portfolioqtrends)
        {
            return new BillingOutputFeeRatesDTO();

        }

        public BillingInputOutputBaseDTO Execute(BillingInputOutputBaseDTO input)
        {
            throw new NotImplementedException();
        }
    }

    public class CalculateFeeAmountsStep : IStep
    {
        public string StepName;

        public TransformBlock<BillingOutputFeeRatesDTO, BillingOutputFeeAmountsDTO> dataFlow;


        public CalculateFeeAmountsStep()
        {
            dataFlow = new TransformBlock<BillingOutputFeeRatesDTO, BillingOutputFeeAmountsDTO>(CalculateFeeAmounts);
        }

        public string AgentName { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public IStep NextStep { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public StepTypes StepType { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public BillingInputOutputBaseDTO Input { get; set; }
        public BillingInputOutputBaseDTO Output { get; set; }

        public string JobId => throw new NotImplementedException();

        public BillingOutputFeeAmountsDTO CalculateFeeAmounts(BillingInputOutputBaseDTO portfolioqtrends)
        {
            //BillingOutputFeeRatesAndAmountsDTO billingOutputFeeRatesAndAmountsDTO =new BillingOutputFeeRatesAndAmountsDTO();

            return new BillingOutputFeeAmountsDTO();
        }

        public BillingInputOutputBaseDTO Execute(BillingInputOutputBaseDTO input)
        {
            return CalculateFeeAmounts(input);
        }
    }
}
