﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Batcher;

namespace DataFlowProcessor
{
    public class BillingInputOutputBaseDTO
    {
        public List<InputPortfolioQtrend> portfolioQtrends;
    }
    public class BillingInputDTO:BillingInputOutputBaseDTO
    {
      
    }

  
}
