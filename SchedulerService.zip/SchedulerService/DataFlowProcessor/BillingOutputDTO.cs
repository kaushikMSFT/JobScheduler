﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataFlowProcessor
{
    public class BillingOutputFeeRatesDTO:BillingInputOutputBaseDTO
    {
        List<PortolioFeeRate> portfoliofeeRates;

    }

    public class BillingOutputFeeAmountsDTO:BillingInputOutputBaseDTO
    {
        List<PortolioFeeRateAndAmount> portfoliosfeeRateAndAmount;

    }

    public enum FeeComponentType
    {
        AdminFee=1,
        ProgramFee=2,
        ManagerFee=3,
        AdvisorFee=4
    }

    public class PortolioFeeRate
    {
        public string Portfolio;
        public FeeComponentType FeeType;
        public float Rate;
    }

    public class PortolioFeeRateAndAmount
    {
        public string Portfolio;
        public FeeComponentType FeeType;
        public float Rate;
        public int ProratedDays;
        public float Amount;
    }
}
